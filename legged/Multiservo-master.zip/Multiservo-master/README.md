# Multiservo

Arduino library to interface with the Amperka Multiservo Shield’s:

- [Multiservo Shield v1](https://amperka.ru/product/arduino-multiservo-shield-v1)
- [Multiservo Shield v2](https://amperka.ru/product/arduino-multiservo-shield)