QuadDisplay2
============

Arduino library for the [QuadDisplay](https://amperka.com/products/troyka-quad-display) module.

Installation
============

1. Download Library in //.zip// format.
2. Open Arduino IDE.
3. Go to «Sketch» → «Include Library» → «Add .ZIP Library».
4. You will be asked to select the library you would like to add. Navigate to the .zip file's location and open it.
